import 'package:flutter/material.dart';
import 'package:contacts_service/contacts_service.dart';

class ContactsScreen extends StatefulWidget {
  @override
  _ContactsScreenState createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  List<Contact> contacts = [];

  @override
  void initState() {
    super.initState();
    _getContacts();
  }

  Future<void> _getContacts() async {
    final Iterable<Contact> contactsData = await ContactsService.getContacts(
      query: '',
      withThumbnails: true,
      photoHighResolution: true,
      orderByGivenName: true,
      iOSLocalizedLabels: true,
      androidLocalizedLabels: true,
    );
    setState(() {
      this.contacts = contactsData.toList();
    });
  }

  String _getInitials(Contact? contact) {
    if (contact == null || contact.displayName == null || contact.displayName!.isEmpty) {
      return '';
    }
    final names = contact.displayName!.split(' ');
    if (names.length > 1) {
      return '${names[0][0]}${names[names.length - 1][0]}';
    } else {
      return names.isNotEmpty ? names[0][0] : '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Contacts')),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          final contact = contacts[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text(_getInitials(contact)),
            ),
            title: Text(contact.displayName ?? ''),
            subtitle: Text('Phone: ${contact.phones?.isNotEmpty == true ? contact.phones!.first.value : ''}'),
            trailing: IconButton(
              icon: Icon(Icons.email),
              onPressed: () {
                // Handle contact email
                print('Contact email: ${contact.emails?.isNotEmpty == true ? contact.emails!.first.value : ''}');
              },
            ),
            onTap: () {
              // Handle contact tap
              print('Contact tapped: ${contact.displayName}');
            },
          );
        },
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ContactsScreen(),
  ));
}
